package wxyandz.firebaseappcourse

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
