import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class SignInPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Center(
            child: Text('Time Tracker'),
          ),
        ),
        body: SafeArea(
            child: Container(
                color: Colors.grey[100],
                child: Center(
                  child: Column(
//            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: <Widget>[
                      SizedBox(height: 150),
                      Text(
                        'Sign in',
                        style: TextStyle(
                          fontSize: 40.0,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      SizedBox(height: 50),
                      SignInButton(
                        buttonColor: Colors.white,
                        imageAssetPosition: 'Images/google-logo.png',
                        buttonText: 'Sign in with Google',
                        textColor: Colors.black87,
                        specificPadding: 10.0,
                      ),
                      SignInButton(
                        buttonColor: Color(0xFF4066B1),
                        imageAssetPosition: 'Images/facebook-logo.png',
                        buttonText: 'Sign in with Facebook',
                        textColor: Colors.white,
                        specificPadding: 10.0,
                      ),
                      SignInButton(
                        buttonColor: Color(0xFF21836B),
                        buttonText: 'Sign in with email',
                        textColor: Colors.white,
                        specificPadding: 15.0,
                      ),
                      Text(
                        'OR',
                        style: TextStyle(
                          fontSize: 15.0,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      SizedBox(
                        height: 10.0,
                      ),
                      SignInButton(
                        buttonColor: Color(0xFFDDEC7C),
                        buttonText: 'Go anonymous',
                        textColor: Colors.black87,
                        specificPadding: 15.0,
                      ),
                    ],
                  ),
                ))));
  }
}

class SignInButton extends StatelessWidget {
  SignInButton({
    this.buttonColor,
    this.imageAssetPosition,
    this.buttonText,
    this.textColor = Colors.black,
    this.specificPadding,
  });
  final Color buttonColor;
  final String imageAssetPosition;
  final String buttonText;
  final Color textColor;
  final double specificPadding;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(right: 20.0, bottom: 10.0, left: 20.0),
      child: RaisedButton(
        color: buttonColor,
        padding: EdgeInsets.only(
            top: specificPadding,
            bottom: specificPadding,
            left: specificPadding,
            right: specificPadding),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: <Widget>[
            Image.asset('$imageAssetPosition'),
            Text(
              '$buttonText',
              style: TextStyle(
                fontSize: 15.0,
                color: textColor,
              ),
            ),
            Opacity(
              opacity: 0.0,
              child: Image.asset('$imageAssetPosition'),
            ),
          ],
        ),
        onPressed: () {},
      ),
    );
  }
}
